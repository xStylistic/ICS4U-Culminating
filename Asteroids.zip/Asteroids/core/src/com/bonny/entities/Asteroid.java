package com.bonny.entities;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.math.MathUtils;

public class Asteroid extends SpaceObject {

	private int type;
	public static final int SMALL = 0;
	public static final int MEDIUM = 1;
	public static final int LARGE = 2;
	
	private int score;

	private int numPoints;
	private float[] distance;

	private boolean remove;

	public Asteroid(float x, float y, int type) {

		this.x = x;
		this.y = y;
		this.type = type;

		if (type == SMALL) {

			numPoints = 8;
			width = height = 18;
			speed = MathUtils.random(70, 100);
			score = 100;

		} else if (type == MEDIUM) {

			numPoints = 10;
			width = height = 36;
			speed = MathUtils.random(50, 60);
			score = 50;

		} else if (type == LARGE) {

			numPoints = 12;
			width = height = 60 ;
			speed = MathUtils.random(20, 30);
			score = 25;

		}

		rotationSpeed = MathUtils.random(-1, 1);

		radians = MathUtils.random((int) (2 * Math.PI));
		dx = MathUtils.cos(radians) * speed;
		dy = MathUtils.sin(radians) * speed;

		shapeX = new float[numPoints];
		shapeY = new float[numPoints];
		distance = new float[numPoints];

		int radius = width / 2;

		for (int i = 0; i < numPoints; i++) {

			distance[i] = MathUtils.random(radius / 2, radius);

		}

		setShape();

	}

	private void setShape() {

		float angle = 0;

		for (int i = 0; i < numPoints; i++) {

			shapeX[i] = x + MathUtils.cos(angle + radians) * distance[i];
			shapeY[i] = y + MathUtils.sin(angle + radians) * distance[i];
			angle += 2 * Math.PI / numPoints;

		}

	}

	public int getType() {

		return type;

	}
	
	public int getScore() {
		
		return score;
		
	}

	public boolean shouldRemove() {

		return remove;

	}

	public void update(float deltaTime) {

		x += dx * deltaTime;
		y += dy * deltaTime;

		radians += rotationSpeed * deltaTime;
		setShape();

		wrap();

	}

	public void draw(ShapeRenderer sr) {
		
		sr.setColor(1, 1, 1, 1);
		sr.begin(ShapeType.Line);
		
		for (int i = 0, j = shapeX.length - 1; i < shapeX.length; j = i++) {

			sr.line(shapeX[i], shapeY[i], shapeX[j], shapeY[j]);
		}
		
		sr.end();
		
	}

}
