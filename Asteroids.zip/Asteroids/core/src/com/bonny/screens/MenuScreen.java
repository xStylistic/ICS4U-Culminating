package com.bonny.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.bonny.managers.GameScreenManager;

public class MenuScreen extends GameScreen {
	
	private SpriteBatch sb;
	
	private BitmapFont titleFont;
	private BitmapFont font;
	
	private FreeTypeFontGenerator fontGen;
	private FreeTypeFontGenerator.FreeTypeFontParameter titleFontParam;
	private FreeTypeFontGenerator.FreeTypeFontParameter fontParam;
	
	private final String title = "Asteroids";
	
	private int currentOption;
	private String[] menuOptions;
	
	public MenuScreen(GameScreenManager gsm) {
		
		super(gsm);
		
	}

	public void initialize() {
		
		sb = new SpriteBatch();
		
		fontGen = new FreeTypeFontGenerator(Gdx.files.internal("Bubble Pixel.TTF"));
		titleFontParam = new FreeTypeFontGenerator.FreeTypeFontParameter();
		titleFontParam.size = 58;
		titleFontParam.color = Color.WHITE;
		titleFont = fontGen.generateFont(titleFontParam); 
		
		fontParam = new FreeTypeFontGenerator.FreeTypeFontParameter();
		fontParam.size = 22;
		fontParam.color = Color.WHITE;
		font = fontGen.generateFont(fontParam); 
		
	}

	public void update(float deltaTime) {
	
		
	}

	public void draw() {

		
	}

	public void handleInput() {
	
		
	}

	public void dispose() {

		
	}

}
