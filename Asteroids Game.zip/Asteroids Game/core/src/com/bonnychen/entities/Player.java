package com.bonnychen.entities;

public class Player extends SpaceObject {
	
	protected boolean left;
	protected boolean right;
	protected boolean up; 
	
	protected float maxSpeed; 
	protected float acceleration;
	protected float deacceleration;  

}
