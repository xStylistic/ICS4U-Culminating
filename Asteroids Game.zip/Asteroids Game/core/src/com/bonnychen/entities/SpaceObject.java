package com.bonnychen.entities;

public class SpaceObject {

	protected float x;
	protected float y;
	
	protected float dx;
	protected float dy; 
	
	protected float radians;
	protected float speed;
	protected float rotationSpeed; 
	
	protected int width;
	protected int height; 
	
	protected float[] shapeX;
	protected float[] shapeY; 
	
}
