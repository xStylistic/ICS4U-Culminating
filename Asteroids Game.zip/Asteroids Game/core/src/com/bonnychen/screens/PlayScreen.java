package com.bonnychen.screens;

import com.bonnychen.managers.GameScreenManager;

public class PlayScreen extends GameScreen {

	public PlayScreen(GameScreenManager gsm) {
		
		super(gsm);
		
	}
	

	public void initialize() {

		
	}

	public void update(float deltaTime) {
		
		 System.out.println("UPDATING SCREEN");
		
	}

	public void draw() {
		
		
	}

	public void handleInput() {
		
		
	}

	public void dispose() {
		
		
	}

}
