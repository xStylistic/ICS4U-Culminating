package com.bonnychen.managers;

import com.bonnychen.screens.GameScreen;
import com.bonnychen.screens.PlayScreen;

public class GameScreenManager {
	
	// current game screen
	private GameScreen gameScreen; 
	
	public static final int MENU = 0;
	public static final int PLAY = 1;
	
	public GameScreenManager() { // the different game screens
		
		setScreen(PLAY);
		
	}
	
	public void setScreen(int screen) {
		
		if(gameScreen != null) gameScreen.dispose(); // gets rid of last game screen
		
		if(screen == MENU) { // switch to the menu screen
			
			// gameScreen = new MenuScreen(this);
			
		}
		
		if(screen == PLAY) { // switch to play screen 
			
			gameScreen = new PlayScreen(this);
			
		}
		
	}
	
	public void update(float deltaTime) { 
		
		gameScreen.update(deltaTime);
		
	}
	
	public void draw() { 
		
		gameScreen.draw();
		
	}

}
